-- ecommerce.sql
-- Database: E-commerce Platform
-- Created for: Product management with variations, attributes, and categories
-- Date: April 23, 2025

-- Create Database
CREATE DATABASE IF NOT EXISTS ecommerce;
USE ecommerce;

-- Table: brand
CREATE TABLE brand (
    BrandID INT AUTO_INCREMENT PRIMARY KEY,
    BrandName VARCHAR(100) NOT NULL UNIQUE,
    Description TEXT
);

-- Table: product_category
CREATE TABLE product_category (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL UNIQUE,
    ParentCategoryID INT,
    FOREIGN KEY (ParentCategoryID) REFERENCES product_category(CategoryID)
);

-- Table: product
CREATE TABLE product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    BrandID INT NOT NULL,
    CategoryID INT NOT NULL,
    ProductName VARCHAR(200) NOT NULL,
    Description TEXT,
    BasePrice DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (BrandID) REFERENCES brand(BrandID),
    FOREIGN KEY (CategoryID) REFERENCES product_category(CategoryID)
);

-- Table: product_item
CREATE TABLE product_item (
    ProductItemID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT NOT NULL,
    SKU VARCHAR(50) NOT NULL UNIQUE,
    Price DECIMAL(10,2) NOT NULL,
    StockQuantity INT NOT NULL DEFAULT 0,
    FOREIGN KEY (ProductID) REFERENCES product(ProductID)
);

-- Table: product_image
CREATE TABLE product_image (
    ProductImageID INT AUTO_INCREMENT PRIMARY KEY,
    ProductItemID INT NOT NULL,
    ImageURL VARCHAR(255) NOT NULL,
    AltText VARCHAR(100),
    IsPrimary BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (ProductItemID) REFERENCES product_item(ProductItemID)
);

-- Table: color
CREATE TABLE color (
    ColorID INT AUTO_INCREMENT PRIMARY KEY,
    ColorName VARCHAR(50) NOT NULL UNIQUE,
    HexCode VARCHAR(7) NOT NULL
);

-- Table: size_category
CREATE TABLE size_category (
    SizeCategoryID INT AUTO_INCREMENT PRIMARY KEY,
    SizeCategoryName VARCHAR(50) NOT NULL UNIQUE
);

-- Table: size_option
CREATE TABLE size_option (
    SizeOptionID INT AUTO_INCREMENT PRIMARY KEY,
    SizeCategoryID INT NOT NULL,
    SizeName VARCHAR(50) NOT NULL,
    SortOrder INT NOT NULL DEFAULT 0,
    FOREIGN KEY (SizeCategoryID) REFERENCES size_category(SizeCategoryID)
);

-- Table: product_variation
CREATE TABLE product_variation (
    VariationID INT AUTO_INCREMENT PRIMARY KEY,
    ProductItemID INT NOT NULL,
    ColorID INT,
    SizeOptionID INT,
    FOREIGN KEY (ProductItemID) REFERENCES product_item(ProductItemID),
    FOREIGN KEY (ColorID) REFERENCES color(ColorID),
    FOREIGN KEY (SizeOptionID) REFERENCES size_option(SizeOptionID)
);

-- Table: attribute_category
CREATE TABLE attribute_category (
    AttributeCategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(50) NOT NULL UNIQUE
);

-- Table: attribute_type
CREATE TABLE attribute_type (
    AttributeTypeID INT AUTO_INCREMENT PRIMARY KEY,
    AttributeCategoryID INT NOT NULL,
    AttributeName VARCHAR(50) NOT NULL,
    DataType ENUM('Text', 'Number', 'Boolean') NOT NULL,
    FOREIGN KEY (AttributeCategoryID) REFERENCES attribute_category(AttributeCategoryID)
);

-- Table: product_attribute
CREATE TABLE product_attribute (
    ProductAttributeID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT NOT NULL,
    AttributeTypeID INT NOT NULL,
    AttributeValue TEXT NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES product(ProductID),
    FOREIGN KEY (AttributeTypeID) REFERENCES attribute_type(AttributeTypeID)
);

-- Sample Data
INSERT INTO brand (BrandName, Description) VALUES
('Nike', 'Leading sportswear brand'),
('Samsung', 'Electronics innovator');

INSERT INTO product_category (CategoryName, ParentCategoryID) VALUES
('Clothing', NULL),
('Electronics', NULL),
('Shoes', 1);

INSERT INTO product (BrandID, CategoryID, ProductName, Description, BasePrice) VALUES
(1, 1, 'Nike T-Shirt', 'Comfortable cotton t-shirt', 29.99),
(2, 2, 'Samsung Galaxy Phone', 'Latest smartphone', 799.99);

INSERT INTO product_item (ProductID, SKU, Price, StockQuantity) VALUES
(1, 'NIKE-TS-BLK-S', 29.99, 100),
(2, 'SAM-GALAXY-A52', 799.99, 50);

INSERT INTO product_image (ProductItemID, ImageURL, AltText, IsPrimary) VALUES
(1, 'https://example.com/nike-ts-black.jpg', 'Black Nike T-Shirt', TRUE),
(2, 'https://example.com/samsung-galaxy.jpg', 'Samsung Galaxy Phone', TRUE);

INSERT INTO color (ColorName, HexCode) VALUES
('Black', '#000000'),
('White', '#FFFFFF');

INSERT INTO size_category (SizeCategoryName) VALUES
('Clothing Sizes'),
('Shoe Sizes');

INSERT INTO size_option (SizeCategoryID, SizeName, SortOrder) VALUES
(1, 'S', 1),
(1, 'M', 2),
(2, '42', 1);

INSERT INTO product_variation (ProductItemID, ColorID, SizeOptionID) VALUES
(1, 1, 1);

INSERT INTO attribute_category (CategoryName) VALUES
('Physical'),
('Technical');

INSERT INTO attribute_type (AttributeCategoryID, AttributeName, DataType) VALUES
(1, 'Material', 'Text'),
(2, 'Battery Life', 'Number');

INSERT INTO product_attribute (ProductID, AttributeTypeID, AttributeValue) VALUES
(1, 1, 'Cotton'),
(2, 2, '4000');

-- Indexes for Performance
CREATE INDEX idx_product_category ON product(CategoryID);
CREATE INDEX idx_product_item_product ON product_item(ProductID);
CREATE INDEX idx_product_variation_item ON product_variation(ProductItemID);
CREATE INDEX idx_product_attribute_product ON product_attribute(ProductID);